sudo cp './sources.list' '/etc/apt/'
sudo cp './raspi.list' '/etc/apt/sources.list.d/'
sudo apt-get update
sudo apt-get install vim -y
sudo apt-get install ppp -y
sudo pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pip -U
sudo pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
sudo pip install Adafruit_ADS1x15 requests pyserial
sudo cp './linux-ppp-scripts/quectel-ppp' '/etc/ppp/peers'
sudo cp './linux-ppp-scripts/quectel-chat-connect' '/etc/ppp/peers'
sudo cp './linux-ppp-scripts/quectel-chat-disconnect' '/etc/ppp/peers'
