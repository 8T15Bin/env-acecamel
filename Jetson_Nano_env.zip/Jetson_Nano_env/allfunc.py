import os 
import time 
import Adafruit_ADS1x15
import serial
import json
import requests

# set wokring directory
os.chdir("/home/asa/Desktop")

#set timestap
timestap = 0

# initialize ADC
adc = Adafruit_ADS1x15.ADS1115(address=0x48,busnum=1)
GAIN = 1

# initialize SerialPort
portx = "/dev/ttyUSB2"
bps = 115200
timex = 0.5
ser = serial.Serial(portx,bps,timeout=timex)
ser.write('AT+QGPS=1\r\n'.encode())
time.sleep(60)

# always measure and receive data
while True:
    #read value
    value_0 = adc.read_adc(0,gain = GAIN,data_rate = 128)
    value_1 = adc.read_adc(1,gain = GAIN,data_rate = 128)
    value_2 = adc.read_adc(2,gain = GAIN,data_rate = 128)
    value_3 = adc.read_adc(3,gain = GAIN,data_rate = 128)

    # get time
    time_now= time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
    timestap = timestap + 1
    hour = timestap//3600
    minute = timestap//60 - hour*60
    second = timestap-minute*60-hour*3600
    time_pass  = str(hour)+'H '+ str(minute) + 'min '+ str(second) + 's: '

    # get GPS
    ser.write("AT+QGPSLOC?\r\n".encode())
    num = ser.inWaiting()
    gps_loc = ser.read(num)

    # write in file.txt
    data = time_pass +"\n" + " A0: "+ str(value_0) + "; A1: " + \
    str(value_1) + "; A2: " + str(value_2)\
    + "; A3: " + str(value_3)+"\n" + time_now + "\r\n" + gps_loc.decode()
    f = open("allfunc.txt","a")
    f.write(data+"\n")
    f.close()
    print(data)

    #json
    post_data = {'TIME':time_now,'A0':value_0,'A1':value_1,'A2':value_2,'A3':value_3,'GPS':gps_loc.decode()}
    post_json = json.dumps(post_data)
    print(post_json)

    #post json
    url = 'http://47.98.39.19:8080/data1'
    headers = {'content-type':'application/json'}
    response = requests.post(url,post_json,headers=headers)

    #delay 1s
    time.sleep(1)
