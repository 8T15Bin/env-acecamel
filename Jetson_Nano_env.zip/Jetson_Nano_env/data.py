import os
import time
import Adafruit_ADS1x15
import serial

#path
os.chdir("/home/asa/Desktop")

#adc
adc = Adafruit_ADS1x15.ADS1115(address=0x48,busnum =1)
GAIN = 1 
timestap = 0

#serial & gps
portx = "/dev/ttyUSB2"
bps = 115200
timex = 0.5
ser = serial.Serial(portx,bps,timeout=timex)
ser.write('AT+QGPS=1\r\n'.encode())

while True:
    timestap = timestap + 1
    print(timestap)

    value_1 = adc.read_adc(0,gain = GAIN,data_rate = 128)
    print("A0:",value_1)
      
    value_2 = adc.read_adc(1,gain = GAIN,data_rate = 128)
    print("A1:",value_2)
    
    value_3 = adc.read_adc(2,gain = GAIN,data_rate = 128)
    print("A2:",value_3)
    
    value_4 = adc.read_adc(3,gain = GAIN,data_rate = 128)
    print("A3:",value_4)

    ser.write("AT+QGPSLOC?\r\n".encode())
    num = ser.inWaiting()
    gps_loc = ser.read(num)
    
    data = str(timestap) + " A0: "+ str(value_1) + " A1: " + str(value_2) \
    + " A2: "+ str(value_3) + " A3: "+ str(value_4) + gps_loc.decode()

    f = open("data.txt","a")
    f.write(data+"\n")
    f.close()
    time.sleep(1)

