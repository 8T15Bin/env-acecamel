sudo touch /etc/systemd/system/rc-local.service
sudo cp './rc-local.service' '/etc/systemd/system/rc-local.service'
sudo cp './rc.local' '/etc'
sudo chmod +x /etc/rc.local
sudo systemctl enable rc-local
sudo systemctl start rc-local.service
sudo cp '/etc/apt/sources.list' '/etc/apt/sources.list.bak'
sudo cp './sources.list' '/etc/apt'
sudo apt-get update
sudo apt-get install ppp
sudo apt-get install python-pip
sudo pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pip -U
sudo cp './pip' '/usr/bin/pip'
sudo cp '/pip2' '/usr/bin/pip2'
sudo pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
sudo pip install Adafruit_ADS1x15 requests pyserial pynmea2
sudo cp './linux-ppp-scripts/quectel-ppp' '/etc/ppp/peers'
sudo cp './linux-ppp-scripts/quectel-chat-connect' '/etc/ppp/peers'
sudo cp './linux-ppp-scripts/quectel-chat-disconnect' '/etc/ppp/peers'
